---
name: product-demo-video-storyteller
description: Create UI-faithful product use-case videos, landing-page hero animations, SaaS walkthroughs, app explainer clips, and proof-driven product motion assets. Use when Codex must turn a real website feature into a 10-30 second video, inspect a product URL/frontend/screenshots for one-to-one visual reconstruction, demonstrate a feature's actual workflow and output, or render a high-resolution no-audio demo with correct feature-specific evidence.
---

# Product Demo Video Storyteller

## Core Intent

Turn a product use case into a concise, premium demo video where the viewer first feels the outcome, then understands the real workflow. Treat the source product as the specification: never substitute generic UI, generic copy, or a generic result screen.

## Non-Negotiable Gates

Do not draw or animate until all three gates are answered in writing:

1. **Visual source of truth** — identify the strongest available source in this order: live page, local frontend components/CSS/assets, screenshots, then a written description. Extract page geometry, labels, controls, empty states, states, icons, colors, type scale, and spacing from that source.
2. **Feature contract** — state the user input, exact trigger control and location, processing behavior, output surface, and whether the feature ends in text, a score/report, an export, or another state. State what must *not* be shown.
3. **Evidence contract** — select an ending that proves the feature's actual value. A detector may end in a score; a writer, refiner, translator, counter, reviewer, or style-profile generator normally ends in its own output, not a fabricated detection report.

If any gate is unknown, inspect the website/frontend or request the missing screenshot before rendering. Never infer a control position, icon, page state, or product result from a different feature.

## Default Workflow

1. **Map the source**: inspect the actual page and, when available, the local frontend. Create a compact visual inventory of every element visible in the video.
2. **Model the feature**: describe the user job, valid input, action/control, processing state, output, and appropriate proof. Read `references/feature-contracts.md`.
3. **Choose the story**: select a feature-appropriate storyboard; do not force `setup -> action -> detection result` onto every product.
4. **Rebuild the UI one-to-one**: match page hierarchy, dimensions, control placement, copy, icons, type, colors, radii, borders, shadows, disabled states, and empty states before adding motion.
5. **Animate humanly**: use readable typing or a believable paste, cursor actions, and restrained easing. Hold no non-explanatory frame for more than two seconds.
6. **Render and compare**: inspect source-to-render frame pairs for fidelity, then verify the result is semantically valid for the feature. Read `references/feature-contracts.md` for the mandatory QA gates.

## Story Structure

Use this only when the feature contract calls for a separate proof screen:

- `0.0-3.2s` — Show the user’s starting context in a familiar app or source surface.
- `3.2-7.0s` — Paste/import into the product UI; placeholder text disappears the moment real text appears.
- `7.0-12.4s` — Trigger the core action; show progress and a meaningful transformed output.
- `12.4-15.0s` — Cut to proof; make the result obvious in one glance.

For output-first features, use `context -> input -> trigger -> product output -> hold`. For real-time tools, use `context -> live input -> live metric update -> hold`. For editors/reviewers, use `context -> input -> action -> edited/reviewed output -> hold`. Do not add an unrelated detector, score, or external app.

## UI Fidelity Rules

- Recreate the actual product page, not a generic mockup. Resolve disagreements with the source hierarchy in the first gate.
- Keep all visible copy in the language requested by the user; default to English for global SaaS ads.
- Use full, realistic feature-relevant text blocks instead of lorem ipsum; make product input/output text bold enough to survive compression. Ensure generated text is readable, grammatical, and does not overlap or become garbled.
- Keep empty-state placeholders visible only while the field is empty. Hide them immediately when text appears.
- Place controls exactly where the real product places them, including per-panel buttons, mode selectors, tabs, upload areas, word counts, and bottom action bars. Do not borrow a button from a related page.
- Preserve real icons rather than approximate drawings. If the frontend imports an icon/component, use the matching asset or path.
- Preserve brand colors, rounded radii, shadows, gradients, and disabled/active button states. Map score colors to the product's thresholds; do not label a warning score as success.
- Mask personal account data shown in source UI, retaining only a safe recognizable prefix when useful (for example, `l****`).
- Avoid showing fake browser chrome unless it helps the story; if used, keep it minimal and premium.

Read `references/motion-style-guide.md` for detailed visual grammar and `references/storyboard-patterns.md` for reusable flows.

## Motion Rules

- Use ease-in/ease-out curves; never linear movement for hero videos.
- Prefer paste reveals for long text and typewriter reveals only for short prompts.
- Make typing human: small pauses, line growth, and readable speed; avoid one-frame text dumps unless representing paste. Use a paste animation for long copied content.
- Highlight causal actions with a cursor, click ripple, pill label, or short blue/green progress bar.
- Use crossfades or gentle slide transitions between apps instead of hard cuts unless the proof moment needs impact.
- Keep final metrics clear: do not overlap labels with large numbers, gauges, charts, or icons. Only display a metric if the feature contract calls for one.

## Product Manager Lens

Before rendering, answer:

- What anxiety or job does the user have?
- What result do they need to believe?
- Which 1-3 UI actions prove the product is easy?
- What final evidence is truthful for this specific feature?
- What can be removed without weakening belief?

If an operation is ethically or legally sensitive, frame the video around legitimate, policy-compliant value. Do not create instructions for deception, fraud, evasion, or bypassing safety systems.

## Rendering Guidance

- Default export: `3840x2160`, `30fps`, `12-15s`, H.264 MP4, no audio.
- Use larger font sizes than static UI would use; video compression punishes thin text.
- Inspect at least: first source/context frame, product empty state, first populated field, action frame, output frame, and final feature-specific evidence frame.
- Compare the rendered frame with the source at the same stage before approving it. Check button location, tab selection, placeholder disappearance, copy, icon silhouette, panel proportions, and score/color semantics.
- If file size is too low for the visual complexity, increase bitrate or lower CRF.
- Keep a poster PNG from the strongest product/proof frame.

Use `scripts/render_product_demo.py` as a small configurable starting point when no app-specific renderer exists.
