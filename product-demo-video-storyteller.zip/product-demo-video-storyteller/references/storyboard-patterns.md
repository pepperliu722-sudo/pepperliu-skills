# Storyboard Patterns

## Pattern A: Generate -> Product -> Proof

Use for AI writing, analysis, research, automation, and transformation tools.

1. Show a familiar source tool generating or containing the starting artifact.
2. Copy or paste into the product.
3. Click one primary action.
4. Show transformed output.
5. End with a report, score, green badge, or before/after result.

## Pattern B: Problem Dashboard -> Fix -> Metric

Use for analytics, monitoring, finance, operations, and security products.

1. Show a messy or risky dashboard.
2. Apply the product action.
3. Show progress or automated reasoning.
4. End with improved metric, cleared alerts, or generated recommendation.

## Pattern C: Upload -> Extract -> Deliverable

Use for document, spreadsheet, PDF, media, OCR, and workflow tools.

1. Show upload/dropzone.
2. Show parsing/extraction.
3. Show structured output.
4. End with export-ready file, approval state, or summary.

## Pattern D: Blank State -> Guided Creation -> Publish

Use for builders, design tools, website tools, and creator products.

1. Show blank canvas or prompt.
2. Show guided generation.
3. Show editable result.
4. End with live/published/success state.

## Proof Moment Options

- Green probability or confidence circle.
- Before/after score card.
- “Approved,” “Passed,” “Published,” or “Ready” status.
- Timeline compressed from hours to seconds.
- Side-by-side text or UI comparison.
- Audit trail, report, receipt, or deploy URL.
