# Motion Style Guide

## Visual Tone

- Premium SaaS landing-page video: bright background, soft blue/green glows, white cards, subtle shadows, rounded corners, calm motion.
- UI must look usable, not like a cartoon. The viewer should believe the product exists and works.
- Use whitespace generously; zoom the product surface enough that text and controls remain readable.

## Color

- Start from the product’s brand palette. Use the primary color for active tabs, progress bars, cursor trails, and primary buttons.
- Use green only for success/proof states unless the brand uses green as primary.
- Keep backgrounds low contrast and UI text high contrast.

## Text

- Hero captions should be short and outcome-led: “Paste into Product,” “One click transforms it,” “Score turns green.”
- Long field content should be realistic, full, and bold enough to read.
- Do not allow placeholders, helper text, or labels to overlap with generated content.

## Timing

- 12-15 seconds is ideal for homepage hero loops.
- Keep the first 2-3 seconds immediately recognizable by the target user.
- Hold the final proof frame long enough for comprehension, usually 1.5-2.0 seconds.

## Effects

- Use progress bars, cursor clicks, and small badges as affordances.
- Use shimmer sparingly for processing states.
- Use a single spotlight glow behind the main card or proof panel.
- Avoid bouncy transitions, excessive parallax, confetti, and music unless explicitly requested.

## QA Checklist

- Verify every visible word is in the requested language.
- Verify placeholders disappear when user content appears.
- Verify primary buttons and controls match their real positions.
- Verify final proof metric and label do not overlap.
- Verify output has no audio if the user requested none.
- Verify resolution, fps, duration, and codec.
