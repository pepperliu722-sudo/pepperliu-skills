# Feature Contracts and QA Gates

## Write This Before Rendering

For each video, write five short lines:

| Field | Required decision |
|---|---|
| User job | What the user is trying to accomplish. |
| Input | The actual content, file, selection, or prompt accepted by the feature. |
| Trigger | Exact button/control text, panel, and state. |
| Output | The page region and content that should change. |
| Evidence | The final state that truthfully proves the feature worked. |

Also list forbidden scenes. Examples: no detector after a text generator; no Humanize button on an AI Create page; no invented footer controls; no Chinese copy in an English asset.

## Ending Selection

| Feature behavior | Correct ending |
|---|---|
| Detection, verification, risk, compliance | Result report with authentic range, threshold color, labels, and flagged details. A high or warning result is valid when it demonstrates detection. |
| Generation, refinement, translation, summarization | Completed output in the correct output panel, readable enough to inspect. |
| Real-time utility such as word counter | Live metric cards and frequency/analysis update while the user types or pastes. |
| Style/profile generation | Generated profile/style output and the page's own save/continue state. |
| File conversion/export | Finished document/preview and export-ready state. |

Never manufacture a green success result merely because it is visually persuasive. Represent the product's own result and thresholds.

## Fidelity QA

Before export, compare reference and video frame-by-frame at these moments:

1. Initial page: nav, title, tabs, active state, background, panel grid.
2. Empty state: helper copy, placeholder, logo/icon, upload zone, disabled buttons.
3. Populated state: placeholder removed; text wraps cleanly; counts and controls remain in their real positions.
4. Trigger state: exact control label, icon, panel, and disabled/loading treatment.
5. Output state: valid feature-specific content; no duplicate copy, gibberish, overflow, overlap, or wrong language.
6. Ending: result content, score color, spacing, and hierarchy are legible in one glance.

Reject and revise when any visible UI element is guessed, copied from another feature, misplaced, unreadable, or semantically unrelated to the feature.
