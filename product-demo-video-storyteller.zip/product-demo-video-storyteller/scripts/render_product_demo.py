#!/usr/bin/env python3
"""Minimal configurable 4K product demo video renderer.

This is a starting point, not a finished visual system. Copy it into the working
project, adapt the drawing functions to the product UI, and render with:

  python render_product_demo.py config.json output.mp4

The config file may include: title, subtitle, promise, product_name, primary,
success, duration, width, height, fps.
"""

from __future__ import annotations

import json
import math
import os
import shutil
import subprocess
import sys
from pathlib import Path

try:
    from PIL import Image, ImageDraw, ImageFont
except ImportError as exc:
    raise SystemExit("Install pillow before rendering: python -m pip install pillow") from exc


def ease(x: float) -> float:
    x = max(0.0, min(1.0, x))
    return 1 - (1 - x) ** 3


def font(size: int, bold: bool = False) -> ImageFont.FreeTypeFont:
    candidates = [
        "/System/Library/Fonts/Supplemental/Arial Bold.ttf" if bold else "/System/Library/Fonts/Supplemental/Arial.ttf",
        "/System/Library/Fonts/Helvetica.ttc",
        "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf" if bold else "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
    ]
    for path in candidates:
        try:
            return ImageFont.truetype(path, size=size)
        except OSError:
            continue
    return ImageFont.load_default()


def rounded(draw: ImageDraw.ImageDraw, box, radius, fill, outline=None, width=1):
    draw.rounded_rectangle(box, radius=radius, fill=fill, outline=outline, width=width)


def frame(config: dict, sec: float) -> Image.Image:
    width = int(config.get("width", 3840))
    height = int(config.get("height", 2160))
    primary = tuple(config.get("primary", [37, 99, 235]))
    success = tuple(config.get("success", [34, 197, 94]))
    ink = (17, 24, 39)
    muted = (100, 116, 139)

    img = Image.new("RGB", (width, height), (244, 248, 255))
    draw = ImageDraw.Draw(img)
    draw.ellipse((-500, -360, 1200, 900), fill=(220, 235, 255))
    draw.ellipse((width - 1100, -320, width + 500, 900), fill=(222, 250, 238))

    duration = float(config.get("duration", 15.0))
    p = sec / duration
    title = config.get("title", "Product workflow in seconds")
    subtitle = config.get("subtitle", "A concise, proof-driven demo.")
    product = config.get("product_name", "Product")
    promise = config.get("promise", "Result verified")

    draw.text((width / 2, 95), title, font=font(72), fill=ink, anchor="mm")
    draw.text((width / 2, 160), subtitle, font=font(34), fill=muted, anchor="mm")

    card = (width * 0.15, height * 0.18, width * 0.85, height * 0.82)
    rounded(draw, card, 48, (255, 255, 255), (226, 232, 240), 2)

    if p < 0.25:
        label = "Start with the user's real context"
        body = "A realistic source artifact appears here. Keep it familiar and readable."
    elif p < 0.72:
        label = f"Paste into {product}"
        body = "User content replaces the placeholder immediately. The primary action becomes available."
        progress = ease((p - 0.25) / 0.47)
        draw.rectangle((card[0] + 120, card[3] - 170, card[0] + 120 + 900 * progress, card[3] - 150), fill=primary)
    else:
        label = promise
        body = "The final proof state should be obvious in one glance."
        cx, cy = width / 2, height / 2 + 80
        r = 170
        draw.ellipse((cx - r, cy - r, cx + r, cy + r), outline=success, width=24, fill=(236, 253, 245))
        draw.text((cx, cy - 20), "6%", font=font(118), fill=(22, 101, 52), anchor="mm")
        draw.text((cx, cy + r + 55), "AI-written probability", font=font(28), fill=muted, anchor="mm")

    draw.text((card[0] + 120, card[1] + 120), label, font=font(64), fill=ink)
    draw.text((card[0] + 120, card[1] + 220), body, font=font(38, bold=True), fill=(51, 65, 85))
    return img


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("Usage: render_product_demo.py config.json output.mp4")
    config = json.loads(Path(sys.argv[1]).read_text())
    output = Path(sys.argv[2]).resolve()
    width = int(config.get("width", 3840))
    height = int(config.get("height", 2160))
    fps = int(config.get("fps", 30))
    duration = float(config.get("duration", 15.0))

    ffmpeg = os.environ.get("FFMPEG") or shutil.which("ffmpeg")
    if not ffmpeg:
        try:
            import imageio_ffmpeg

            ffmpeg = imageio_ffmpeg.get_ffmpeg_exe()
        except ImportError as exc:
            raise SystemExit("Install ffmpeg or imageio-ffmpeg before rendering.") from exc

    cmd = [
        ffmpeg, "-y", "-f", "rawvideo", "-pix_fmt", "rgb24",
        "-s", f"{width}x{height}", "-r", str(fps), "-i", "-",
        "-an", "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "15",
        "-movflags", "+faststart", str(output),
    ]
    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE)
    assert proc.stdin is not None
    for index in range(int(duration * fps)):
        proc.stdin.write(frame(config, index / fps).tobytes())
    proc.stdin.close()
    if proc.wait() != 0:
        raise SystemExit("ffmpeg failed")
    print(output)


if __name__ == "__main__":
    main()
